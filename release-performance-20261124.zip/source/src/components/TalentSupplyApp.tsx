import { agencyAvatarSprites } from '@/data/agencyAvatarSprites';
import { douyinAvatarMap } from '@/data/douyinAvatarMap';
import { industryAvatarSprites } from '@/data/industryAvatarSprites';
import { INDUSTRY_OPTIONS } from '@/data/industryOptions';
import industryProfiles from '@/data/industryTalentProfiles.json';
import { rewriteNodeSalesOwners } from '@/lib/nodeExportPolicy';
import { clearPublicSheetCache, fetchPublicSheet } from '@/lib/publicSheet';
import { shuffleNodeRows } from '@/lib/shuffleNodeRows';
import { downloadRowsTable } from '@/lib/tableCsv';
import {
  ArrowUpRight,
  BookOpen,
  Bot,
  CalendarDays,
  ChevronRight,
  Download,
  ExternalLink,
  Globe2,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  UsersRound,
} from 'lucide-react';
import { Suspense, lazy, useEffect, useMemo, useRef, useState } from 'react';
import { FeaturedTalentSidebarEntry } from './AgencyBookletRail';
import { BookletModule } from './BookletModule';
import { FeaturedTalentIntro } from './FeaturedTalentIntro';
import { IpCampaignModule } from './IpCampaignModule';
import { SharedAvatarVisual } from './P0Avatar';
import { TeamModule } from './TeamModule';

import { ModuleBanner, type ModuleKey } from './ModuleBanner';

const AgencyModule = lazy(() =>
  import('./AgencyModule').then(module => ({ default: module.AgencyModule })),
);
const P0AuthorsModule = lazy(() =>
  import('./P0AuthorsModule').then(module => ({
    default: module.P0AuthorsModule,
  })),
);

type P0ProfileDoc = { profiles: Record<string, string> };

type SourceOption = {
  id: string;
  label: string;
  sheetId: string;
  count: number;
};

const DISPLAY_LIMIT = 99;
const INDUSTRIES: SourceOption[] = INDUSTRY_OPTIONS;

const NODES: SourceOption[] = [
  { id: 'node-1111', label: '双 11', sheetId: '0iHZMy', count: 16500 },
  { id: 'node-1212', label: '双 12', sheetId: '1tVppi', count: 16500 },
  { id: 'node-newyear', label: '跨年 / 元旦', sheetId: '2pzQvF', count: 16500 },
  {
    id: 'node-christmas',
    label: '平安夜 / 圣诞',
    sheetId: '3PUkix',
    count: 16500,
  },
];

const MODULES = [
  {
    key: 'industry' as const,
    label: '行业',
    desc: '11 个重点行业',
    icon: Globe2,
  },
  {
    key: 'node' as const,
    label: '节点',
    desc: 'Q4 营销节点',
    icon: CalendarDays,
  },
  { key: 'ip' as const, label: 'IP', desc: '特色内容资产', icon: Star },
  {
    key: 'team' as const,
    label: '达人团',
    desc: '组合式供给',
    icon: UsersRound,
  },
  {
    key: 'ai' as const,
    label: '代理商使用模块',
    desc: '重点达人 · 报价与全维度',
    icon: Bot,
  },
];

const INDUSTRY_URL =
  'https://bytedance.larkoffice.com/sheets/ShwKsQe36hxTiTtEF0Dc4W4cnPe';
const NODE_URL =
  'https://bytedance.larkoffice.com/sheets/BfFYsEunBhI0PKtGKzfc6smbnic';

function text(value: unknown) {
  if (value === null || value === undefined || value === '') return '-';
  return String(value);
}

function compactPrice(value: unknown) {
  const raw = text(value).replace(/,/g, '');
  const amount = Number(raw);
  if (!Number.isFinite(amount) || amount <= 0) return '待询价';
  return amount >= 10000
    ? `¥${(amount / 10000).toFixed(amount % 10000 ? 1 : 0)}万`
    : `¥${amount}`;
}

function FeishuErrorPanel({
  error,
  sourceUrl,
}: { error: unknown; sourceUrl: string }) {
  const message =
    error instanceof Error
      ? error.message
      : String(
          (error as { message?: unknown })?.message ?? error ?? '加载失败',
        );
  const unauthorized = /has not authorized Feishu/i.test(message);
  const forbidden = /91403|Forbidden/i.test(message);
  return (
    <div className="state-panel error-panel">
      <ShieldCheck size={22} />
      <div>
        <strong>
          {unauthorized
            ? '需要先授权飞书'
            : forbidden
              ? '暂无数据源权限'
              : '数据加载失败'}
        </strong>
        <p>
          {unauthorized
            ? '请先在 Aime 完成飞书授权，再刷新本页。'
            : forbidden
              ? '请向表格所有者申请访问权限，获批后刷新。'
              : '数据源暂时不可用，请稍后重试。'}
        </p>
      </div>
      <a
        href={unauthorized ? 'https://aime.bytedance.net' : sourceUrl}
        target="_blank"
        rel="noreferrer"
      >
        去处理 <ArrowUpRight size={14} />
      </a>
    </div>
  );
}

function TalentCard({
  row,
  headers,
  mode,
  p0ProfileSecIds,
}: {
  row: unknown[];
  headers: string[];
  mode: 'industry' | 'node';
  p0ProfileSecIds: Record<string, string>;
}) {
  const get = (name: string) => row[headers.indexOf(name)];
  const name = text(get('星图达人抖音昵称'));
  const city = text(get('常驻城市'));
  const talentType = text(get('达人类型'));
  const fans = text(get('达人抖音粉丝量级'));
  const category = text(get(mode === 'node' ? '细分行业' : '推荐行业'));
  const middlePrice = compactPrice(get('抖音21-60s长视频报价(元)'));
  const longPrice = compactPrice(get('抖音60s以上视频报价(元)'));
  // 字符串 ID 保留全部精度，仅清理空白及表格常见的 .0 后缀。
  const id = text(get('达人星图id')).trim().replace(/\.0+$/, '');
  const xingtuUrl =
    id !== '-' ? `https://www.xingtu.cn/ad/creator/author/douyin/${id}` : '#';
  const talentProfile = (
    industryProfiles.profiles as Record<
      string,
      { profileUrl: string | null; displayId: string }
    >
  )[id];
  // 行业快照与 P0 作者库均只收录已核验的 sec_uid 真实主页；未核验时不输出伪链接。
  const p0SecUid = p0ProfileSecIds[id];
  const douyinUrl =
    talentProfile?.profileUrl ??
    (p0SecUid ? `https://www.douyin.com/user/${p0SecUid}` : null);
  const displayIdText =
    talentProfile?.displayId || douyinAvatarMap[id]?.displayId || '';
  const subtitle =
    mode === 'node'
      ? [text(get('节点')), category].filter(value => value !== '-').join(' · ')
      : [city, talentType].filter(value => value !== '-').join(' · ');

  return (
    <article className="talent-card industry-card">
      <div className="talent-topline">
        {douyinUrl ? (
          <a
            className="avatar avatar-photo"
            href={douyinUrl}
            target="_blank"
            rel="noreferrer"
            aria-label={`打开 ${name} 的抖音主页`}
          >
            <SharedAvatarVisual id={id} name={name} preferIndustry />
          </a>
        ) : (
          <span
            className="avatar avatar-disabled"
            aria-label={`${name} 暂未获取到抖音主页`}
          >
            <SharedAvatarVisual id={id} name={name} preferIndustry />
          </span>
        )}
        <div className="talent-title">
          <strong>{name}</strong>
          <span>{subtitle || '精选达人'}</span>
          {displayIdText ? <em>抖音号：{displayIdText}</em> : null}
        </div>
      </div>
      <div className="tag-row">
        <span>{category}</span>
        <span>{fans}</span>
      </div>
      <div className="price-board">
        <div>
          <b>{middlePrice}</b>
          <small>21–60s</small>
        </div>
        <div>
          <b>{longPrice}</b>
          <small>60s+</small>
        </div>
      </div>
      <div className="card-actions">
        {douyinUrl ? (
          <a href={douyinUrl} target="_blank" rel="noreferrer">
            抖音主页 <ExternalLink size={13} />
          </a>
        ) : (
          <span
            className="card-link-disabled"
            title="暂未获取到该达人的抖音主页链接"
          >
            抖音主页
          </span>
        )}
        <a href={xingtuUrl} target="_blank" rel="noreferrer">
          星图主页 <ExternalLink size={13} />
        </a>
      </div>
    </article>
  );
}

function LiveTalentModule({
  mode,
  options,
  selected,
  onSelect,
  onNavigate,
  previousNodeFirst,
}: {
  previousNodeFirst?: { current: string | null };
  onNavigate: (module: ModuleKey) => void;
  mode: 'industry' | 'node';
  options: SourceOption[];
  selected: string;
  onSelect: (id: string) => void;
}) {
  const [query, setQuery] = useState('');
  const [reloadToken, setReloadToken] = useState(0);
  const [downloading, setDownloading] = useState(false);
  const [downloadNotice, setDownloadNotice] = useState('');
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [p0ProfileSecIds, setP0ProfileSecIds] = useState<
    Record<string, string>
  >({});

  useEffect(() => {
    let active = true;
    // The publication-scoped mapping is fetched only when industry/node is opened.
    // Fall back to the bundled mapping for development or a failed static request.
    fetch(new URL('./profile-links.json', document.baseURI))
      .then(response => {
        if (!response.ok) throw new Error('主页映射暂时不可用');
        return response.json() as Promise<Record<string, string>>;
      })
      .catch(() =>
        import('@/data/p0ProfileUrls.json').then(
          module => (module.default as unknown as P0ProfileDoc).profiles,
        ),
      )
      .then(profiles => {
        if (active) setP0ProfileSecIds(profiles);
      })
      .catch(error => {
        console.error(error);
      });
    return () => {
      active = false;
    };
  }, []);
  const [fullData, setFullData] = useState<{
    headers: string[];
    rows: unknown[][];
    capturedAt?: string;
  } | null>(null);
  const current = options.find(item => item.id === selected) ?? options[0];
  const isNode = mode === 'node';
  const sourceUrl = `${isNode ? NODE_URL : INDUSTRY_URL}?sheet=${current.sheetId}`;

  useEffect(() => {
    let active = true;
    setLoading(true);
    setLoadError(null);
    setDownloadNotice('');
    clearPublicSheetCache(current.id);
    fetchPublicSheet(current.id)
      .then(result => {
        if (!active) return;
        setFullData({
          headers: result.headers.map(text),
          rows: result.rows,
          capturedAt: result.capturedAt,
        });
      })
      .catch(error => {
        if (!active) return;
        console.error(error);
        setLoadError('当前分组数据加载失败，请稍后重试。');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [current.id, reloadToken]);

  const [shuffleSeed] = useState(() => Math.floor(Math.random() * 4294967296));
  const [previousFirst] = useState(() => previousNodeFirst?.current ?? null);
  const headers = fullData?.headers ?? [];
  const rows = useMemo(() => {
    const sourceRows = fullData?.rows ?? [];
    if (!isNode) return sourceRows;
    const idIndex = headers.indexOf('达人星图id');
    return shuffleNodeRows(
      sourceRows,
      shuffleSeed,
      row => text(row[idIndex]),
      previousFirst,
    ).sort((left, right) => {
      const hasAvatar = (row: unknown[]) => {
        const id = text(row[idIndex]).trim().replace(/\.0+$/, '');
        return Boolean(industryAvatarSprites[id] || agencyAvatarSprites[id]);
      };
      return Number(!hasAvatar(left)) - Number(!hasAvatar(right));
    });
  }, [fullData?.rows, isNode, headers, shuffleSeed, previousFirst]);
  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter(row =>
      row.some(value => text(value).toLowerCase().includes(needle)),
    );
  }, [query, rows]);
  const hasBaseData = headers.length > 0 && rows.length > 0;

  const handleDownload = async () => {
    const safeLabel = current.label.replace(/[\\/:*?"<>|]/g, '_');
    const modulePrefix = isNode ? '节点' : '行业';
    if (!fullData || downloading) return;
    setDownloading(true);
    setDownloadNotice('');
    try {
      const needle = query.trim().toLowerCase();
      const filteredRows =
        !isNode && needle
          ? fullData.rows.filter(row =>
              row.some(value => text(value).toLowerCase().includes(needle)),
            )
          : fullData.rows;
      const exportRows = isNode
        ? rewriteNodeSalesOwners(fullData.headers, filteredRows)
        : filteredRows;
      const snapshotDate = fullData.capturedAt?.slice(0, 10);
      downloadRowsTable(
        `${modulePrefix}-${safeLabel}-${exportRows.length}条${snapshotDate ? `-源表快照${snapshotDate}` : ''}.csv`,
        fullData.headers,
        exportRows,
      );
      setDownloadNotice(
        `${current.label}：已生成 ${exportRows.length.toLocaleString()} 条下载数据${snapshotDate ? `（完整源表快照 ${snapshotDate}）` : ''}。`,
      );
    } catch (error) {
      console.error(error);
      window.alert('表格生成失败，请稍后重试。');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <section className={`content-section enter ${isNode ? 'node-module' : ''}`}>
      <div
        className="section-heading"
        id={isNode ? undefined : 'module-content'}
      >
        <div>
          <span className="eyebrow">MODULE · {isNode ? '02' : '01'}</span>
          <h2>{isNode ? '节点精选达人' : '行业精选达人'}</h2>
          <p>
            {isNode
              ? '对外公开版：按营销节点与行业规则汇总真实达人供给。'
              : '对外公开版：覆盖 11 个重点行业，汇总真实达人与合作信息。'}
          </p>
        </div>
        <button
          type="button"
          className="table-download-btn"
          disabled={!hasBaseData || downloading}
          onClick={handleDownload}
        >
          {downloading ? (
            <RefreshCw size={15} className="spin" />
          ) : (
            <Download size={15} />
          )}
          {downloading ? '正在生成表格…' : '点击下载表格'}
        </button>
      </div>
      {downloadNotice && <output>{downloadNotice}</output>}
      <div className="filter-bar">
        <div className="pill-scroll">
          {options.map(item => (
            <button
              key={item.id}
              className={item.id === current.id ? 'pill active' : 'pill'}
              onClick={() => onSelect(item.id)}
            >
              {item.label}
              <span>{item.count.toLocaleString()}</span>
            </button>
          ))}
        </div>
        <div className="search-box">
          <Search size={16} />
          <input
            aria-label="搜索达人"
            value={query}
            onChange={event => setQuery(event.target.value)}
            placeholder="搜索达人 / 城市 / 类型…"
          />
        </div>
      </div>
      <div className="data-summary">
        <div>
          <span>当前分组</span>
          <strong>{current.label}</strong>
        </div>
        <div>
          <span>供给规模</span>
          <strong>{current.count.toLocaleString()}</strong>
        </div>
        <div>
          <span>本页展示</span>
          <strong>{Math.min(filtered.length, DISPLAY_LIMIT)}</strong>
        </div>
        <button
          onClick={() => setReloadToken(token => token + 1)}
          disabled={loading}
          type="button"
          title="重新读取本地快照"
        >
          <RefreshCw size={15} className={loading ? 'spin' : ''} />
          重新读取
        </button>
      </div>
      {isNode && <ModuleBanner module="node" onNavigate={onNavigate} />}
      <div id={isNode ? 'module-content' : undefined}>
        {loading && (
          <div className="card-grid">
            {['a', 'b', 'c', 'd', 'e', 'f'].map(id => (
              <div className="talent-card skeleton" key={id} />
            ))}
          </div>
        )}
        {!loading && loadError && (
          <div className="state-panel error-panel">{loadError}</div>
        )}
        {!loading && !loadError && !hasBaseData && (
          <div className="state-panel error-panel">
            当前分组暂无可展示数据，请切换分组或稍后重试。
          </div>
        )}
        {!loading && !loadError && hasBaseData && (
          <>
            <div className="result-line">
              <span>
                优先展示前 {DISPLAY_LIMIT} 位供给，当前匹配 {filtered.length} 位
              </span>
              <span className="live-dot">PUBLIC · 本地快照</span>
            </div>
            {filtered.length > 0 ? (
              <div className="card-grid">
                {filtered.slice(0, DISPLAY_LIMIT).map(row => (
                  <TalentCard
                    key={`${current.id}-${text(row[headers.indexOf('达人星图id')])}`}
                    row={row}
                    headers={headers}
                    mode={mode}
                    p0ProfileSecIds={p0ProfileSecIds}
                  />
                ))}
              </div>
            ) : (
              <div className="state-panel">
                没有找到匹配的达人，换个关键词试试。
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}

function PendingModule({ module }: { module: ModuleKey }) {
  const info = {
    ip: {
      title: 'IP 精选供给',
      text: '聚合特色内容 IP、栏目资产与可商业化合作方向。',
      icon: Star,
    },
    team: {
      title: '达人团供给',
      text: '按场景组合达人矩阵，支持品牌批量筛选与协同投放。',
      icon: UsersRound,
    },
    ai: {
      title: '代理商使用模块',
      text: '代理商重点与千川代理商供给入口。',
      icon: Bot,
    },
  }[module as 'ip' | 'team' | 'ai'];
  const Icon = info.icon;
  return (
    <section
      id="module-content"
      className="content-section enter pending-module"
    >
      <div className="pending-orb">
        <Icon size={40} />
      </div>
      <span className="eyebrow">MATERIALS · PENDING</span>
      <h2>{info.title}</h2>
      <p>{info.text}</p>
      <div className="pending-card">
        <Sparkles size={22} />
        <div>
          <strong>模块已预留，等待供给材料</strong>
          <span>
            补充对应飞书表格链接后，可直接接入同款实时筛选与达人卡片。
          </span>
        </div>
      </div>
    </section>
  );
}

function App() {
  const [module, setModule] = useState<ModuleKey>(() => {
    if (typeof window === 'undefined') return 'industry';
    const requested = new URLSearchParams(window.location.search).get('module');
    return requested === 'featured' ||
      requested === 'booklet' ||
      MODULES.some(item => item.key === requested)
      ? (requested as ModuleKey)
      : 'industry';
  });
  const [industry, setIndustry] = useState(INDUSTRIES[0].id);
  const previousNodeFirst = useRef<string | null>(null);
  const [node, setNode] = useState(NODES[3].id);
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <Sparkles size={20} />
          </div>
          <div>
            <strong>精选达人</strong>
          </div>
        </div>
        <nav>
          <FeaturedTalentSidebarEntry
            onOpen={() => setModule('featured')}
            active={module === 'featured'}
          />
          <button
            type="button"
            className={module === 'booklet' ? 'nav-item active' : 'nav-item'}
            onClick={() => setModule('booklet')}
          >
            <BookOpen size={18} />
            <span>
              <b>精选达人推荐刊例</b>
              <small>双旦 / 双11 / 中秋国庆 · 三份特刊</small>
            </span>
            <ChevronRight size={15} />
          </button>
          {MODULES.map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                className={module === item.key ? 'nav-item active' : 'nav-item'}
                onClick={() => setModule(item.key)}
              >
                <Icon size={18} />
                <span>
                  <b>{item.label}</b>
                  <small>{item.desc}</small>
                </span>
                <ChevronRight size={15} />
              </button>
            );
          })}
        </nav>
      </aside>
      <main>
        <div className="module-topbar">
          <span>
            精选达人供给 /{' '}
            {module === 'featured'
              ? '精选达人介绍'
              : module === 'booklet'
                ? '精选达人推荐刊例'
                : MODULES.find(item => item.key === module)?.label}
          </span>
        </div>
        {module === 'featured' && <FeaturedTalentIntro />}
        {module === 'booklet' && <BookletModule />}
        {module !== 'node' && module !== 'featured' && module !== 'booklet' && (
          <ModuleBanner module={module} onNavigate={setModule} />
        )}
        {module === 'industry' && (
          <LiveTalentModule
            onNavigate={setModule}
            key={industry}
            mode="industry"
            options={INDUSTRIES}
            selected={industry}
            onSelect={setIndustry}
          />
        )}
        {module === 'node' && (
          <LiveTalentModule
            onNavigate={setModule}
            key={node}
            mode="node"
            previousNodeFirst={previousNodeFirst}
            options={NODES}
            selected={node}
            onSelect={setNode}
          />
        )}
        {module === 'ip' && (
          <div id="module-content">
            <IpCampaignModule />
          </div>
        )}
        {module === 'team' && <TeamModule />}
        {module === 'ai' && (
          <Suspense
            fallback={
              <div className="state-panel">正在加载代理商达人资料…</div>
            }
          >
            <AgencyModule />
            <P0AuthorsModule />
          </Suspense>
        )}
        <footer>
          <span>精选达人供给库 v1.0 · Powered by 飞书数据</span>
          <span>© 2026 Talent Supply</span>
        </footer>
      </main>
    </div>
  );
}

export function TalentSupplyApp() {
  return <App />;
}
